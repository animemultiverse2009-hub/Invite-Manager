import { Client, GatewayIntentBits, Collection, EmbedBuilder } from 'discord.js';
import { readFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load config
const config = JSON.parse(readFileSync(join(__dirname, 'config.json'), 'utf-8'));

// Create client
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildInvites
  ]
});

// Initialize collections
client.commands = new Collection();
client.invites = new Map();

// Load commands
const invitesCommand = await import('./commands/invites.js');
const setwelcomeCommand = await import('./commands/setwelcome.js');
const setgoodbyeCommand = await import('./commands/setgoodbye.js');
const invitelistCommand = await import('./commands/invitelist.js');
const setupInvitePanelCommand = await import('./commands/setup-invite-panel.js');

client.commands.set(invitesCommand.data.name, invitesCommand);
client.commands.set(setwelcomeCommand.data.name, setwelcomeCommand);
client.commands.set(setgoodbyeCommand.data.name, setgoodbyeCommand);
client.commands.set(invitelistCommand.data.name, invitelistCommand);
client.commands.set(setupInvitePanelCommand.data.name, setupInvitePanelCommand);

// Load events
const readyEvent = await import('./events/ready.js');
const guildMemberAddEvent = await import('./events/guildMemberAdd.js');
const guildMemberRemoveEvent = await import('./events/guildMemberRemove.js');

// Register event handlers
client.once('ready', () => readyEvent.execute(client));
client.on('guildMemberAdd', (member) => guildMemberAddEvent.execute(member, client));
client.on('guildMemberRemove', (member) => guildMemberRemoveEvent.execute(member, client));

// Handle slash commands
client.on('interactionCreate', async interaction => {
  // Handle slash commands
  if (interaction.isChatInputCommand()) {
    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
      await command.execute(interaction);
    } catch (error) {
      console.error('Error executing command:', error);
      const reply = { content: 'There was an error executing this command!', ephemeral: true };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(reply);
      } else {
        await interaction.reply(reply);
      }
    }
  }
  
  // Handle button interactions
  if (interaction.isButton()) {
    if (interaction.customId === 'check_invites') {
      try {
        const dataDir = join(__dirname, 'data');
        const invitesPath = join(dataDir, 'invites.json');
        
        function loadJSON(path) {
          if (!existsSync(path)) {
            return {};
          }
          return JSON.parse(readFileSync(path, 'utf-8'));
        }
        
        const invitesData = loadJSON(invitesPath);
        const userStats = invitesData[interaction.user.id] || {
          total: 0,
          real: 0,
          fake: 0,
          left: 0,
          rejoin: 0,
          bonus: 0,
          alts: 0
        };
        
        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle(`📊 Invite Stats for ${interaction.user.username}`)
          .setThumbnail(interaction.user.displayAvatarURL({ dynamic: true }))
          .setDescription([
            `**Total:** ${userStats.total}`,
            `**Real:** ${userStats.real}`,
            `**Fake:** ${userStats.fake}`,
            `**Left:** ${userStats.left}`,
            `**Rejoins:** ${userStats.rejoin}`,
            `**Bonus:** ${userStats.bonus}`,
            `**New/Alt accounts invited:** ${userStats.alts}`
          ].join('\n'))
          .setTimestamp()
          .setFooter({ text: `Requested by ${interaction.user.username}` });
        
        await interaction.reply({ embeds: [embed], ephemeral: true });
        
      } catch (error) {
        console.error('Error handling check_invites button:', error);
        await interaction.reply({
          content: '❌ An error occurred while fetching your invite statistics.',
          ephemeral: true
        });
      }
    }
  }
});

// Login
client.login(config.token);