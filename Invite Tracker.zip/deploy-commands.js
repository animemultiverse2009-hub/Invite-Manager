import { REST, Routes } from 'discord.js';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Load config
const config = JSON.parse(readFileSync(join(__dirname, 'config.json'), 'utf-8'));

// Load commands
const invitesCommand = await import('./commands/invites.js');
const setwelcomeCommand = await import('./commands/setwelcome.js');
const setgoodbyeCommand = await import('./commands/setgoodbye.js');
const invitelistCommand = await import('./commands/invitelist.js');
const setupInvitePanelCommand = await import('./commands/setup-invite-panel.js');

const commands = [
  invitesCommand.data.toJSON(),
  setwelcomeCommand.data.toJSON(),
  setgoodbyeCommand.data.toJSON(),
  invitelistCommand.data.toJSON(),
  setupInvitePanelCommand.data.toJSON()
];

// Construct and prepare REST module
const rest = new REST().setToken(config.token);

// Deploy commands
(async () => {
  try {
    console.log(`Started refreshing ${commands.length} application (/) commands.`);

    // Register commands to specific guild (faster for testing)
    const data = await rest.put(
      Routes.applicationGuildCommands(config.clientId, config.guildId),
      { body: commands }
    );

    console.log(`Successfully reloaded ${data.length} application (/) commands.`);
  } catch (error) {
    console.error('Error deploying commands:', error);
  }
})();