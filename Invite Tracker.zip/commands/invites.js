import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');
const invitesPath = join(dataDir, 'invites.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

export const data = new SlashCommandBuilder()
  .setName('invites')
  .setDescription('Check invite statistics')
  .addUserOption(option =>
    option
      .setName('user')
      .setDescription('The user to check invites for (leave empty for yourself)')
      .setRequired(false)
  );

export async function execute(interaction) {
  try {
    // Get target user (or command user if no target specified)
    const targetUser = interaction.options.getUser('user') || interaction.user;
    
    // Load invite data
    const invitesData = loadJSON(invitesPath);
    
    // Get user's invite stats
    const userStats = invitesData[targetUser.id] || {
      total: 0,
      real: 0,
      fake: 0,
      left: 0,
      rejoin: 0,
      bonus: 0,
      alts: 0
    };
    
    // Create embed
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`📊 Invite Stats for ${targetUser.username}`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
      .setDescription([
        `**Total:** ${userStats.total}`,
        `**Real:** ${userStats.real}`,
        `**Fake:** ${userStats.fake}`,
        `**Left:** ${userStats.left}`,
        `**Rejoins:** ${userStats.rejoin}`,
        `**Bonus:** ${userStats.bonus}`,
        `**New/Alt accounts invited:** ${userStats.alts}`
      ].join('\n'))
      .setTimestamp()
      .setFooter({ text: `Requested by ${interaction.user.username}` });
    
    await interaction.reply({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error executing invites command:', error);
    await interaction.reply({
      content: '❌ An error occurred while fetching invite statistics.',
      ephemeral: true
    });
  }
}