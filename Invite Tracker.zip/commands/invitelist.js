import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');
const inviterMappingPath = join(dataDir, 'inviter-mapping.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

export const data = new SlashCommandBuilder()
  .setName('invitelist')
  .setDescription('See which members a user invited')
  .addUserOption(option =>
    option
      .setName('user')
      .setDescription('The user to check (leave empty for yourself)')
      .setRequired(false)
  )
  .addStringOption(option =>
    option
      .setName('filter')
      .setDescription('Filter the list')
      .addChoices(
        { name: 'All', value: 'all' },
        { name: 'Still in server', value: 'active' },
        { name: 'Left server', value: 'left' }
      )
      .setRequired(false)
  );

export async function execute(interaction) {
  try {
    await interaction.deferReply();
    
    // Get target user (or command user if no target specified)
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const filter = interaction.options.getString('filter') || 'all';
    
    // Load inviter mapping
    const inviterMapping = loadJSON(inviterMappingPath);
    
    // Find all members invited by this user
    const invitedMembers = [];
    
    for (const [memberId, inviterId] of Object.entries(inviterMapping)) {
      if (inviterId === targetUser.id) {
        // Check if member is still in server
        const member = interaction.guild.members.cache.get(memberId);
        const isInServer = !!member;
        
        // Apply filter
        if (filter === 'active' && !isInServer) continue;
        if (filter === 'left' && isInServer) continue;
        
        // Try to fetch user info
        let userInfo;
        try {
          if (member) {
            userInfo = member.user;
          } else {
            userInfo = await interaction.client.users.fetch(memberId).catch(() => null);
          }
        } catch {
          userInfo = null;
        }
        
        invitedMembers.push({
          id: memberId,
          user: userInfo,
          inServer: isInServer,
          joinedAt: member ? member.joinedTimestamp : null
        });
      }
    }
    
    // Sort by status (in server first) and then by join date
    invitedMembers.sort((a, b) => {
      if (a.inServer && !b.inServer) return -1;
      if (!a.inServer && b.inServer) return 1;
      if (a.joinedAt && b.joinedAt) return b.joinedAt - a.joinedAt;
      return 0;
    });
    
    if (invitedMembers.length === 0) {
      await interaction.editReply({
        content: `${targetUser.username} hasn't invited anyone yet${filter !== 'all' ? ` (with filter: ${filter})` : ''}.`
      });
      return;
    }
    
    // Create pages (10 members per page)
    const membersPerPage = 10;
    const totalPages = Math.ceil(invitedMembers.length / membersPerPage);
    const currentPage = 0;
    
    const generateEmbed = (page) => {
      const start = page * membersPerPage;
      const end = start + membersPerPage;
      const pageMembers = invitedMembers.slice(start, end);
      
      // Count stats
      const inServerCount = invitedMembers.filter(m => m.inServer).length;
      const leftCount = invitedMembers.length - inServerCount;
      
      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(`📋 Members invited by ${targetUser.username}`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .setDescription(
          `**Total Invited:** ${invitedMembers.length}\n` +
          `**✅ Still in server:** ${inServerCount}\n` +
          `**❌ Left server:** ${leftCount}\n` +
          (filter !== 'all' ? `\n*Filtered by: ${filter}*` : '')
        )
        .setFooter({ text: `Page ${page + 1}/${totalPages} • Requested by ${interaction.user.username}` })
        .setTimestamp();
      
      // Add members to embed
      let membersList = '';
      pageMembers.forEach((data, index) => {
        const globalIndex = start + index + 1;
        const username = data.user ? data.user.username : `Unknown User (${data.id})`;
        const status = data.inServer ? '✅' : '❌';
        const joinInfo = data.joinedAt ? `<t:${Math.floor(data.joinedAt / 1000)}:R>` : 'Unknown';
        
        membersList += `**${globalIndex}.** ${status} ${username}${data.inServer ? ` • Joined ${joinInfo}` : ''}\n`;
      });
      
      embed.addFields({ name: 'Members', value: membersList || 'None' });
      
      return embed;
    };
    
    const embed = generateEmbed(currentPage);
    await interaction.editReply({ embeds: [embed] });
    
  } catch (error) {
    console.error('Error executing invitelist command:', error);
    
    const errorMessage = {
      content: '❌ An error occurred while fetching the invite list.',
      ephemeral: true
    };
    
    if (interaction.deferred) {
      await interaction.editReply(errorMessage);
    } else {
      await interaction.reply(errorMessage);
    }
  }
}