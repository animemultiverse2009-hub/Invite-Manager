import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');
const settingsPath = join(dataDir, 'settings.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

function saveJSON(path, data) {
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
}

export const data = new SlashCommandBuilder()
  .setName('setup-invite-panel')
  .setDescription('Setup the invite tracking panel')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand(subcommand =>
    subcommand
      .setName('create')
      .setDescription('Create the invite panel in this channel')
      .addStringOption(option =>
        option
          .setName('title')
          .setDescription('Panel title')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('description')
          .setDescription('Panel description (Use {user} for mention, {server} for server name)')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('color')
          .setDescription('Embed color in hex (e.g., #5865F2)')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('button-text')
          .setDescription('Button text')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('button-emoji')
          .setDescription('Button emoji (e.g., ✅)')
          .setRequired(false)
      )
  )
  .addSubcommand(subcommand =>
    subcommand
      .setName('config')
      .setDescription('Configure panel settings')
      .addStringOption(option =>
        option
          .setName('title')
          .setDescription('Panel title')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('description')
          .setDescription('Panel description')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('color')
          .setDescription('Embed color in hex (e.g., #5865F2)')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('button-text')
          .setDescription('Button text')
          .setRequired(false)
      )
      .addStringOption(option =>
        option
          .setName('button-emoji')
          .setDescription('Button emoji')
          .setRequired(false)
      )
  )
  .addSubcommand(subcommand =>
    subcommand
      .setName('view')
      .setDescription('View current panel configuration')
  );

export async function execute(interaction) {
  try {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    
    // Load settings
    const settings = loadJSON(settingsPath);
    if (!settings[guildId]) {
      settings[guildId] = {};
    }
    
    // Initialize invite panel settings if they don't exist
    if (!settings[guildId].invitePanel) {
      settings[guildId].invitePanel = {
        title: 'Check your invites!',
        description: '➡️ **Click** the button below to check your invite count.\nOnly users who **join** with your **invite link** and stay in the server will count.',
        color: '#5865F2',
        buttonText: 'Check Invites',
        buttonEmoji: '✅'
      };
    }
    
    if (subcommand === 'create') {
      const title = interaction.options.getString('title') || settings[guildId].invitePanel.title;
      const description = interaction.options.getString('description') || settings[guildId].invitePanel.description;
      const color = interaction.options.getString('color') || settings[guildId].invitePanel.color;
      const buttonText = interaction.options.getString('button-text') || settings[guildId].invitePanel.buttonText;
      const buttonEmoji = interaction.options.getString('button-emoji') || settings[guildId].invitePanel.buttonEmoji;
      
      // Update settings if custom values provided
      if (interaction.options.getString('title')) settings[guildId].invitePanel.title = title;
      if (interaction.options.getString('description')) settings[guildId].invitePanel.description = description;
      if (interaction.options.getString('color')) settings[guildId].invitePanel.color = color;
      if (interaction.options.getString('button-text')) settings[guildId].invitePanel.buttonText = buttonText;
      if (interaction.options.getString('button-emoji')) settings[guildId].invitePanel.buttonEmoji = buttonEmoji;
      
      saveJSON(settingsPath, settings);
      
      // Create the embed
      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color.startsWith('#') ? parseInt(color.slice(1), 16) : parseInt(color, 16))
        .setTimestamp();
      
      // Create the button
      const button = new ButtonBuilder()
        .setCustomId('check_invites')
        .setLabel(buttonText)
        .setStyle(ButtonStyle.Success);
      
      if (buttonEmoji) {
        button.setEmoji(buttonEmoji);
      }
      
      const row = new ActionRowBuilder()
        .addComponents(button);
      
      // Send the panel
      await interaction.channel.send({
        embeds: [embed],
        components: [row]
      });
      
      await interaction.reply({
        content: '✅ Invite panel created successfully!',
        ephemeral: true
      });
    }
    else if (subcommand === 'config') {
      const title = interaction.options.getString('title');
      const description = interaction.options.getString('description');
      const color = interaction.options.getString('color');
      const buttonText = interaction.options.getString('button-text');
      const buttonEmoji = interaction.options.getString('button-emoji');
      
      let updated = [];
      
      if (title) {
        settings[guildId].invitePanel.title = title;
        updated.push('title');
      }
      if (description) {
        settings[guildId].invitePanel.description = description;
        updated.push('description');
      }
      if (color) {
        settings[guildId].invitePanel.color = color;
        updated.push('color');
      }
      if (buttonText) {
        settings[guildId].invitePanel.buttonText = buttonText;
        updated.push('button text');
      }
      if (buttonEmoji) {
        settings[guildId].invitePanel.buttonEmoji = buttonEmoji;
        updated.push('button emoji');
      }
      
      if (updated.length === 0) {
        await interaction.reply({
          content: '⚠️ No settings were updated. Please provide at least one option.',
          ephemeral: true
        });
        return;
      }
      
      saveJSON(settingsPath, settings);
      
      await interaction.reply({
        content: `✅ Updated: ${updated.join(', ')}`,
        ephemeral: true
      });
    }
    else if (subcommand === 'view') {
      const config = settings[guildId].invitePanel;
      
      const embed = new EmbedBuilder()
        .setTitle('📋 Invite Panel Configuration')
        .setColor(config.color.startsWith('#') ? parseInt(config.color.slice(1), 16) : parseInt(config.color, 16))
        .addFields(
          { name: 'Title', value: config.title },
          { name: 'Description', value: config.description },
          { name: 'Color', value: config.color },
          { name: 'Button Text', value: config.buttonText },
          { name: 'Button Emoji', value: config.buttonEmoji || 'None' }
        )
        .setFooter({ text: 'Use /setup-invite-panel config to modify these settings' });
      
      await interaction.reply({
        embeds: [embed],
        ephemeral: true
      });
    }
    
  } catch (error) {
    console.error('Error in setup-invite-panel command:', error);
    
    const errorMessage = {
      content: '❌ An error occurred while setting up the invite panel.',
      ephemeral: true
    };
    
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(errorMessage);
    } else {
      await interaction.reply(errorMessage);
    }
  }
}