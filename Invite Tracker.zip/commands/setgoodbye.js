import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');
const settingsPath = join(dataDir, 'settings.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

function saveJSON(path, data) {
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
}

export const data = new SlashCommandBuilder()
  .setName('setgoodbye')
  .setDescription('Configure goodbye messages')
  .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
  .addSubcommand(subcommand =>
    subcommand
      .setName('channel')
      .setDescription('Set the goodbye message channel')
      .addChannelOption(option =>
        option
          .setName('channel')
          .setDescription('The channel to send goodbye messages')
          .setRequired(true)
      )
  )
  .addSubcommand(subcommand =>
    subcommand
      .setName('message')
      .setDescription('Set the goodbye message')
      .addStringOption(option =>
        option
          .setName('message')
          .setDescription('Use {user} for mention, {username} for name, {server} for server name, {inviter} for who invited')
          .setRequired(true)
      )
  )
  .addSubcommand(subcommand =>
    subcommand
      .setName('toggle')
      .setDescription('Enable or disable goodbye messages')
      .addBooleanOption(option =>
        option
          .setName('enabled')
          .setDescription('Enable or disable')
          .setRequired(true)
      )
  )
  .addSubcommand(subcommand =>
    subcommand
      .setName('view')
      .setDescription('View current goodbye message settings')
  );

export async function execute(interaction) {
  try {
    const subcommand = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    
    // Load settings
    const settings = loadJSON(settingsPath);
    if (!settings[guildId]) {
      settings[guildId] = {
        welcome: {
          enabled: false,
          channelId: null,
          message: 'Welcome {user} to {server}! You were invited by {inviter}.'
        },
        goodbye: {
          enabled: false,
          channelId: null,
          message: '{username} has left {server}. They were invited by {inviter}.'
        }
      };
    }
    
    if (subcommand === 'channel') {
      const channel = interaction.options.getChannel('channel');
      settings[guildId].goodbye.channelId = channel.id;
      saveJSON(settingsPath, settings);
      
      await interaction.reply({
        content: `✅ Goodbye messages will be sent to ${channel}`,
        ephemeral: true
      });
    }
    else if (subcommand === 'message') {
      const message = interaction.options.getString('message');
      settings[guildId].goodbye.message = message;
      saveJSON(settingsPath, settings);
      
      await interaction.reply({
        content: `✅ Goodbye message updated!\n\n**Preview:**\n${message.replace('{user}', interaction.user).replace('{username}', interaction.user.username).replace('{server}', interaction.guild.name).replace('{inviter}', 'InviterName')}`,
        ephemeral: true
      });
    }
    else if (subcommand === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled');
      settings[guildId].goodbye.enabled = enabled;
      saveJSON(settingsPath, settings);
      
      await interaction.reply({
        content: `✅ Goodbye messages ${enabled ? 'enabled' : 'disabled'}`,
        ephemeral: true
      });
    }
    else if (subcommand === 'view') {
      const config = settings[guildId].goodbye;
      const channel = config.channelId ? `<#${config.channelId}>` : 'Not set';
      
      await interaction.reply({
        embeds: [{
          title: '👋 Goodbye Message Settings',
          color: 0xED4245,
          fields: [
            { name: 'Status', value: config.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
            { name: 'Channel', value: channel, inline: true },
            { name: 'Message', value: config.message || 'Not set' }
          ]
        }],
        ephemeral: true
      });
    }
    
  } catch (error) {
    console.error('Error in setgoodbye command:', error);
    await interaction.reply({
      content: '❌ An error occurred while updating settings.',
      ephemeral: true
    });
  }
}