export async function execute(client) {
  console.log(`✅ Logged in as ${client.user.tag}`);
  
  // Cache invites for all guilds
  for (const guild of client.guilds.cache.values()) {
    try {
      const invites = await guild.invites.fetch();
      const inviteMap = new Map();
      
      invites.forEach(invite => {
        inviteMap.set(invite.code, invite.uses);
      });
      
      client.invites.set(guild.id, inviteMap);
      console.log(`📊 Cached ${invites.size} invites for ${guild.name}`);
    } catch (error) {
      console.error(`Failed to fetch invites for ${guild.name}:`, error);
    }
  }
  
  console.log('🚀 Bot is ready and tracking invites!');
}