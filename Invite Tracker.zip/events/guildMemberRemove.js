import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');

// Ensure data directory exists
if (!existsSync(dataDir)) {
  mkdirSync(dataDir, { recursive: true });
}

const invitesPath = join(dataDir, 'invites.json');
const joinsPath = join(dataDir, 'joins.json');
const inviterMappingPath = join(dataDir, 'inviter-mapping.json');
const settingsPath = join(dataDir, 'settings.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

function saveJSON(path, data) {
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
}

export async function execute(member, client) {
  try {
    const guild = member.guild;
    
    // Fetch current invites
    const newInvites = await guild.invites.fetch();
    
    // Update cached invites
    const inviteMap = new Map();
    newInvites.forEach(invite => {
      inviteMap.set(invite.code, invite.uses);
    });
    client.invites.set(guild.id, inviteMap);
    
    // Load data
    const invitesData = loadJSON(invitesPath);
    const inviterMapping = loadJSON(inviterMappingPath);
    
    // Find who invited this member
    const inviterUserId = inviterMapping[member.id];
    
    // Store inviter name for goodbye message
    let inviterName = 'Unknown';
    if (inviterUserId && invitesData[inviterUserId]) {
      // Try to fetch the inviter user
      try {
        const inviter = await client.users.fetch(inviterUserId);
        inviterName = inviter.tag;
      } catch {
        inviterName = inviterUserId === 'vanity' ? 'Vanity URL' : 'Unknown';
      }
    }
    
    if (inviterUserId && invitesData[inviterUserId]) {
      // Decrease real invites, increase left invites
      if (invitesData[inviterUserId].real > 0) {
        invitesData[inviterUserId].real--;
      }
      invitesData[inviterUserId].left++;
      
      // Also mark as fake if it wasn't already
      // (a member leaving makes their invite "fake")
      invitesData[inviterUserId].fake++;
      
      // Save updated data
      saveJSON(invitesPath, invitesData);
      
      console.log(`❌ ${member.user.tag} left - updated stats for inviter ${inviterUserId}`);
    } else {
      console.log(`❌ ${member.user.tag} left but inviter not found in records`);
    }
    
    // Send goodbye message if configured
    const settings = loadJSON(settingsPath);
    const guildSettings = settings[guild.id];
    
    if (guildSettings && guildSettings.goodbye && guildSettings.goodbye.enabled && guildSettings.goodbye.channelId) {
      const goodbyeChannel = guild.channels.cache.get(guildSettings.goodbye.channelId);
      
      if (goodbyeChannel) {
        // Replace placeholders in message
        let goodbyeMessage = guildSettings.goodbye.message
          .replace(/{user}/g, `<@${member.id}>`)
          .replace(/{username}/g, member.user.username)
          .replace(/{server}/g, guild.name)
          .replace(/{inviter}/g, inviterName)
          .replace(/{membercount}/g, guild.memberCount.toString());
        
        try {
          await goodbyeChannel.send(goodbyeMessage);
        } catch (error) {
          console.error('Failed to send goodbye message:', error);
        }
      }
    }
    
  } catch (error) {
    console.error('Error in guildMemberRemove:', error);
  }
}