import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dataDir = join(dirname(__dirname), 'data');

// Ensure data directory exists
if (!existsSync(dataDir)) {
  mkdirSync(dataDir, { recursive: true });
}

const invitesPath = join(dataDir, 'invites.json');
const joinsPath = join(dataDir, 'joins.json');
const inviterMappingPath = join(dataDir, 'inviter-mapping.json');
const settingsPath = join(dataDir, 'settings.json');

function loadJSON(path) {
  if (!existsSync(path)) {
    writeFileSync(path, '{}', 'utf-8');
    return {};
  }
  return JSON.parse(readFileSync(path, 'utf-8'));
}

function saveJSON(path, data) {
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf-8');
}

export async function execute(member, client) {
  try {
    const guild = member.guild;
    
    // Fetch current invites
    const newInvites = await guild.invites.fetch();
    const oldInvites = client.invites.get(guild.id) || new Map();
    
    // Find which invite was used
    let usedInvite = null;
    let inviterUserId = null;
    
    // Check regular invites
    for (const [code, invite] of newInvites) {
      const oldUses = oldInvites.get(code) || 0;
      if (invite.uses > oldUses) {
        usedInvite = invite;
        inviterUserId = invite.inviter?.id;
        break;
      }
    }
    
    // Check for vanity URL
    if (!usedInvite && guild.vanityURLCode) {
      const vanityInvite = newInvites.find(i => i.code === guild.vanityURLCode);
      if (vanityInvite) {
        usedInvite = vanityInvite;
        inviterUserId = 'vanity';
      }
    }
    
    // Update cached invites
    const inviteMap = new Map();
    newInvites.forEach(invite => {
      inviteMap.set(invite.code, invite.uses);
    });
    client.invites.set(guild.id, inviteMap);
    
    // If no inviter found, stop here
    if (!inviterUserId) {
      console.log(`❓ Could not determine who invited ${member.user.tag}`);
      return;
    }
    
    // Load data
    const invitesData = loadJSON(invitesPath);
    const joinsData = loadJSON(joinsPath);
    const inviterMapping = loadJSON(inviterMappingPath);
    
    // Store who invited this member
    inviterMapping[member.id] = inviterUserId;
    
    // Initialize inviter data if not exists
    if (!invitesData[inviterUserId]) {
      invitesData[inviterUserId] = {
        total: 0,
        real: 0,
        fake: 0,
        left: 0,
        rejoin: 0,
        bonus: 0,
        alts: 0
      };
    }
    
    // Check if this is a rejoin
    const memberJoinHistory = joinsData[member.id] || [];
    const isRejoin = memberJoinHistory.length > 0;
    
    // Add current join timestamp
    memberJoinHistory.push(Date.now());
    joinsData[member.id] = memberJoinHistory;
    
    // Check if account is new (less than 7 days old)
    const accountAge = Date.now() - member.user.createdTimestamp;
    const sevenDaysInMs = 7 * 24 * 60 * 60 * 1000;
    const isNewAccount = accountAge < sevenDaysInMs;
    
    // Update invite stats
    invitesData[inviterUserId].total++;
    
    if (isRejoin) {
      invitesData[inviterUserId].rejoin++;
    } else if (isNewAccount) {
      invitesData[inviterUserId].fake++;
      invitesData[inviterUserId].alts++;
    } else {
      invitesData[inviterUserId].real++;
    }
    
    // Save data
    saveJSON(invitesPath, invitesData);
    saveJSON(joinsPath, joinsData);
    saveJSON(inviterMappingPath, inviterMapping);
    
    console.log(`✅ ${member.user.tag} joined via invite from ${inviterUserId === 'vanity' ? 'vanity URL' : usedInvite.inviter?.tag || 'unknown'}`);
    if (isRejoin) console.log(`   └─ Counted as REJOIN`);
    if (isNewAccount) console.log(`   └─ Flagged as NEW/ALT account`);
    
    // Send welcome message if configured
    const settings = loadJSON(settingsPath);
    const guildSettings = settings[guild.id];
    
    if (guildSettings && guildSettings.welcome && guildSettings.welcome.enabled && guildSettings.welcome.channelId) {
      const welcomeChannel = guild.channels.cache.get(guildSettings.welcome.channelId);
      
      if (welcomeChannel) {
        // Get inviter name
        let inviterName = 'Unknown';
        if (inviterUserId === 'vanity') {
          inviterName = 'Vanity URL';
        } else if (usedInvite && usedInvite.inviter) {
          inviterName = usedInvite.inviter.tag;
        }
        
        // Replace placeholders in message
        let welcomeMessage = guildSettings.welcome.message
          .replace(/{user}/g, `<@${member.id}>`)
          .replace(/{username}/g, member.user.username)
          .replace(/{server}/g, guild.name)
          .replace(/{inviter}/g, inviterName)
          .replace(/{membercount}/g, guild.memberCount.toString());
        
        try {
          await welcomeChannel.send(welcomeMessage);
        } catch (error) {
          console.error('Failed to send welcome message:', error);
        }
      }
    }
    
  } catch (error) {
    console.error('Error in guildMemberAdd:', error);
  }
}